class HeadPhone {
  String image;
  String title;
  int color;
  HeadPhone({this.color, this.image, this.title});
}

var products = [
  HeadPhone(image: "assets/img_01.png", title: "Pampas", color: 6),
  HeadPhone(image: "assets/img_02.png", title: "Plattan TLE", color: 12),
  HeadPhone(image: "assets/img_03.png", title: "Plattan 2", color: 1),
];
